package com.ringbot.qa;
import java.nio.ByteBuffer;
import java.util.Arrays;
final class Detector {
 static final int N=1080; static final double STEP=360.0/N;
 static final double[] COS=new double[N],SIN=new double[N];
 static{for(int i=0;i<N;i++){COS[i]=Math.cos(i*Math.PI*2/N);SIN[i]=Math.sin(i*Math.PI*2/N);}}
 static double wrap(double a){return ((a+180)%360+360)%360-180;}
 static class Result{double angle,target,width;boolean valid,targetValid;}
 static Result scan(ByteBuffer b,int w,int h,int row,int pixel,double cy,double radius){
  Result out=new Result();
  int[] shaft=new int[N];
  double cx=w*.5,yy=h*cy,rr=w*radius;
  double[] inner={.634,.706,.778,.85,.908},outer={.990,1.025,1.060};
  for(int i=0;i<N;i++){
   for(double r:inner){
    int c=color(b,w,h,row,pixel,cx,yy,rr*r,i);
    if(Math.max((c>>16)&255,Math.max((c>>8)&255,c&255))<85)shaft[i]++;
   }
  }
  int best=-1,peak=0;
  for(int i=0;i<N;i++){
   int v=0;for(int d=-7;d<=7;d++)v+=shaft[(i+d+N)%N];
   if(v>peak){peak=v;best=i;}
  }
  if(peak<30)return out;
  double nx=0,ny=0;
  for(int d=-12;d<=12;d++){
   int idx=(best+d+N)%N;int wgt=shaft[idx];
   if(wgt>0){nx+=COS[idx]*wgt;ny+=SIN[idx]*wgt;}
  }
  out.valid=true;
  out.angle=(Math.toDegrees(Math.atan2(ny,nx))+360.0)%360.0;

  int[] bgR=new int[3],bgG=new int[3],bgB=new int[3];
  int[] sr=new int[100],sg=new int[100],sb=new int[100];
  for(int k=0;k<3;k++){
   int ns=0;
   for(int i=0;i<N;i+=12){
    double ang=i*STEP;
    if(Math.abs(wrap(ang-out.angle))<15.0||Math.abs(wrap(ang-270.0))<28.0)continue;
    int c=color(b,w,h,row,pixel,cx,yy,rr*outer[k],i);
    sr[ns]=(c>>16)&255;sg[ns]=(c>>8)&255;sb[ns]=c&255;ns++;
   }
   if(ns<15)return out;
   Arrays.sort(sr,0,ns);Arrays.sort(sg,0,ns);Arrays.sort(sb,0,ns);
   if(k==1){
    int iqr=(sr[(ns*3)/4]-sr[ns/4])+(sg[(ns*3)/4]-sg[ns/4])+(sb[(ns*3)/4]-sb[ns/4]);
    if(iqr>140)return out;
   }
   bgR[k]=sr[ns/2];bgG[k]=sg[ns/2];bgB[k]=sb[ns/2];
  }

  boolean[] whiteMask=new boolean[N],skipText=new boolean[N];
  for(int i=0;i<N;i++){
   if(Math.abs(wrap(i*STEP-270.0))>=26.0)continue;
   for(int k=0;k<3;k++){
    int c=color(b,w,h,row,pixel,cx,yy,rr*outer[k],i);
    int r=(c>>16)&255,g=(c>>8)&255,bl=c&255;
    int mx=Math.max(r,Math.max(g,bl)),mn=Math.min(r,Math.min(g,bl));
    if(mn>238&&(mx-mn)<12){whiteMask[i]=true;break;}
   }
  }
  for(int i=0;i<N;i++){
   if(whiteMask[i]){
    for(int d=-3;d<=3;d++)skipText[(i+d+N)%N]=true;
   }
  }

  int[] zone=new int[N];
  for(int i=0;i<N;i++){
   if(skipText[i]||Math.abs(wrap(i*STEP-out.angle))<9.0)continue;
   for(int k=0;k<3;k++){
    int c=color(b,w,h,row,pixel,cx,yy,rr*outer[k],i);
    int r=(c>>16)&255,g=(c>>8)&255,bl=c&255;
    int mx=Math.max(r,Math.max(g,bl)),mn=Math.min(r,Math.min(g,bl));
    if(mx<115||(mn>240&&(mx-mn)<10))continue;
    int dist=Math.abs(r-bgR[k])+Math.abs(g-bgG[k])+Math.abs(bl-bgB[k]);
    if(dist>=85)zone[i]++;
   }
  }

  final int MAX_GAP=14;
  int start=-1,consec=0;
  for(int i=0;i<N+MAX_GAP+2;i++){
   int idx=i%N;
   if(zone[idx]<2){
    consec++;
    if(consec>MAX_GAP){start=idx;break;}
   }else consec=0;
  }
  if(start==-1)return out;

  int bestScore=0;
  double bestAngle=0,bestWidth=0;
  int cScore=0,cActive=0,gap=0,firstOff=-1,lastOff=-1;
  double cSx=0,cSy=0;
  for(int step=0;step<=N;step++){
   int idx=(start+step)%N;
   boolean active=(step<N)&&(zone[idx]>=2);
   if(active){
    if(cActive==0)firstOff=step;
    lastOff=step;
    cActive++;cScore+=zone[idx];
    cSx+=COS[idx];cSy+=SIN[idx];
    gap=0;
   }else if(cActive>0){
    gap++;
    if(gap>MAX_GAP||step==N){
     double spanDeg=(lastOff-firstOff+1)*STEP;
     if(cActive>=3&&spanDeg<=95.0&&cScore>bestScore){
      bestScore=cScore;
      bestAngle=(Math.toDegrees(Math.atan2(cSy,cSx))+360.0)%360.0;
      bestWidth=spanDeg;
     }
     cScore=0;cActive=0;gap=0;cSx=0;cSy=0;
    }
   }
  }
  if(bestScore>0){
   out.target=bestAngle;
   out.width=bestWidth;
   out.targetValid=true;
  }
  return out;
 }
 static int color(ByteBuffer b,int w,int h,int row,int pix,double cx,double cy,double r,int i){
  int x=(int)Math.round(cx+r*COS[i]),y=(int)Math.round(cy+r*SIN[i]);
  if(x<0||x>=w||y<0||y>=h)return 0xffffff;
  int p=y*row+x*pix;if(p+2>=b.limit())return 0xffffff;
  return ((b.get(p)&255)<<16)|((b.get(p+1)&255)<<8)|(b.get(p+2)&255);
 }
}
