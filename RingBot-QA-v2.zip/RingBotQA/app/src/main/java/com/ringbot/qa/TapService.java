package com.ringbot.qa;
import android.accessibilityservice.*; import android.graphics.Path; import android.view.accessibility.*;
public class TapService extends AccessibilityService {
 static volatile TapService instance;
 @Override public void onServiceConnected(){instance=this;}
 @Override public void onAccessibilityEvent(AccessibilityEvent e){}
 @Override public void onInterrupt(){}
 @Override public void onDestroy(){instance=null;super.onDestroy();}
 boolean allowed(String target){try {AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null)return false;CharSequence p=root.getPackageName();boolean match=target!=null&&target.contentEquals(p);root.recycle();return match;}catch(Exception e){return false;}}
 boolean tap(String target,float x,float y){if(!allowed(target))return false;Path path=new Path();path.moveTo(x,y);return dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path,0,6)).build(),null,null);}
}
