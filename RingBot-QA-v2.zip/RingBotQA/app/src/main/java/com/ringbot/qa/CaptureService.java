package com.ringbot.qa;
import android.app.*;import android.content.*;import android.graphics.PixelFormat;import android.hardware.display.*;import android.media.*;import android.media.projection.*;import android.os.*;import android.util.DisplayMetrics;import android.view.WindowManager;
public class CaptureService extends Service {
 MediaProjection projection;VirtualDisplay display;ImageReader reader;
 HandlerThread worker,tapWorker;Handler handler,tapHandler;
 String target;int w,h,sw,sh;
 double cy,r,delay,minDelay,tx,ty,lastAngle,velocity,frameDt=0.020,goal=Double.NaN,goalWidth=5.0;
 long lastTime,lastImgTs,lastTap,lastGoal;int samples;boolean armed=true;volatile boolean stopping;
 @Override public IBinder onBind(Intent i){return null;}
 @Override public int onStartCommand(Intent i,int flags,int id){
  if(i==null||"STOP".equals(i.getAction())){stopSelf();return START_NOT_STICKY;}
  if(projection!=null)return START_NOT_STICKY;
  try{
   NotificationManager nm=getSystemService(NotificationManager.class);
   nm.createNotificationChannel(new NotificationChannel("qa","RingBot QA",NotificationManager.IMPORTANCE_LOW));
   PendingIntent stop=PendingIntent.getService(this,1,new Intent(this,CaptureService.class).setAction("STOP"),PendingIntent.FLAG_IMMUTABLE);
   startForeground(9,new Notification.Builder(this,"qa").setContentTitle("RingBot QA running").setContentText("Adaptive precision mode • tap Stop to end").setSmallIcon(android.R.drawable.ic_media_pause).addAction(new Notification.Action.Builder(null,"Stop",stop).build()).setOngoing(true).build());
   target=i.getStringExtra("pkg");cy=i.getDoubleExtra("y",.462);r=i.getDoubleExtra("r",.347);
   delay=i.getDoubleExtra("delay",40);minDelay=i.getDoubleExtra("minDelay",24);
   tx=i.getDoubleExtra("tx",.5);ty=i.getDoubleExtra("ty",.62);
   DisplayMetrics m=new DisplayMetrics();getSystemService(WindowManager.class).getDefaultDisplay().getRealMetrics(m);
   sw=m.widthPixels;sh=m.heightPixels;w=Math.min(sw,720);h=Math.round(sh*(float)w/sw);
   worker=new HandlerThread("ring-analysis");worker.start();handler=new Handler(worker.getLooper());
   tapWorker=new HandlerThread("tap-timer",android.os.Process.THREAD_PRIORITY_URGENT_AUDIO);tapWorker.start();tapHandler=new Handler(tapWorker.getLooper());
   projection=getSystemService(MediaProjectionManager.class).getMediaProjection(i.getIntExtra("result",0),(Intent)i.getParcelableExtra("data"));
   projection.registerCallback(new MediaProjection.Callback(){@Override public void onStop(){stopSelf();}},handler);
   reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,3);reader.setOnImageAvailableListener(this::frame,handler);
   display=projection.createVirtualDisplay("RingBot QA",w,h,m.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,handler);
   return START_NOT_STICKY;
  }catch(Exception e){stopSelf();return START_NOT_STICKY;}
 }
 void reset(){if(tapHandler!=null)tapHandler.removeCallbacksAndMessages(null);lastTime=0;lastImgTs=0;velocity=0;samples=0;goal=Double.NaN;armed=true;lastGoal=0;}
 void frame(ImageReader ir){
  if(stopping)return;
  try(Image im=ir.acquireLatestImage()){
   if(im==null)return;
   TapService tap=TapService.instance;
   if(tap==null||!tap.allowed(target)){reset();return;}
   long captureTime=SystemClock.elapsedRealtimeNanos();
   long imgTs=im.getTimestamp();
   Image.Plane p=im.getPlanes()[0];
   Detector.Result d=Detector.scan(p.getBuffer(),w,h,p.getRowStride(),p.getPixelStride(),cy,r);
   long now=SystemClock.elapsedRealtimeNanos();
   double scanMs=(now-captureTime)/1e6;
   if(!d.valid){if(captureTime-lastTime>150_000_000L){lastTime=0;lastImgTs=0;samples=0;}return;}
   if(lastTime!=0){
    double dt=(captureTime-lastTime)/1e9;
    if(imgTs>0&&lastImgTs>0){
     double imgDt=(imgTs-lastImgTs)/1e9;
     if(imgDt>.004&&imgDt<.20)dt=imgDt;
    }
    if(dt>.004&&dt<.20){
     frameDt=0.75*frameDt+0.25*dt;
     double v=Detector.wrap(d.angle-lastAngle)/dt;
     if(Math.abs(v)<2200&&Math.abs(v)>5){
      if(samples>0&&velocity*v<0){
       tapHandler.removeCallbacksAndMessages(null);
       velocity=v;samples=1;
      }else{
       velocity=samples==0?v:0.45*velocity+0.55*v;
       samples++;
      }
     }else samples=0;
    }else samples=0;
   }
   lastAngle=d.angle;lastTime=captureTime;lastImgTs=imgTs;
   if(d.targetValid){
    if(Double.isNaN(goal)||(Math.abs(Detector.wrap(d.target-goal))>6.5&&Math.abs(Detector.wrap(d.angle-d.target))>11.0)){
     goal=d.target;goalWidth=d.width;armed=true;
    }else if(Math.abs(Detector.wrap(d.angle-goal))>16.0){
     goal=(goal+0.3*Detector.wrap(d.target-goal)+360.0)%360.0;
     goalWidth=0.6*goalWidth+0.4*d.width;
    }
    lastGoal=now;
   }
   if(!armed&&!Double.isNaN(goal)&&now-lastTap>380_000_000L&&Math.abs(Detector.wrap(d.angle-goal))>30.0){
    armed=true;
   }
   if(!armed||samples<2||Double.isNaN(goal)||now-lastGoal>800_000_000L||now-lastTap<130_000_000L||Math.abs(velocity)<15)return;
   double speed=Math.abs(velocity),dir=Math.signum(velocity);
   double t=Math.max(0.0,Math.min(1.0,(speed-120.0)/140.0));
   double effDelay=delay+(minDelay-delay)*t;
   double pred=d.angle+velocity*((effDelay+scanMs)/1000.0);
   double signedErr=Detector.wrap(goal-pred)*dir;
   double halfWin=Math.max(1.2,Math.min(3.5,goalWidth*0.45));
   double maxWaitSec=Math.min(Math.max(frameDt,0.014),0.040)*1.25;
   double maxLookahead=Math.max(halfWin,speed*maxWaitSec);
   if(signedErr>=-halfWin&&signedErr<=maxLookahead){
    long waitMs=signedErr>0?Math.round((signedErr/speed)*1000.0):0L;
    if(waitMs<=48){
     armed=false;lastTap=now+waitMs*1_000_000L;
     final float fx=(float)(tx*sw),fy=(float)(ty*sh);
     tapHandler.removeCallbacksAndMessages(null);
     if(waitMs<=1){tap.tap(target,fx,fy);}
     else{tapHandler.postDelayed(()->{if(!stopping&&TapService.instance!=null)TapService.instance.tap(target,fx,fy);},waitMs);}
    }
   }
  }catch(Exception e){reset();}
 }
 @Override public void onDestroy(){stopping=true;if(tapHandler!=null)tapHandler.removeCallbacksAndMessages(null);if(reader!=null)reader.setOnImageAvailableListener(null,null);if(display!=null)display.release();if(reader!=null)reader.close();if(projection!=null)projection.stop();if(worker!=null)worker.quitSafely();if(tapWorker!=null)tapWorker.quitSafely();super.onDestroy();}
}
