# RingBot QA (prototype)
Android source for testing your own installed **debuggable** game. Does not work with non-debuggable release apps. No stealth or protection bypass. No network permission; screen frames are processed in memory. Not built or tested on Android in the authoring environment (SDK unavailable).

## Build
Open the project in Android Studio with JDK 17, Android SDK 35 and Gradle 8.9; sync and choose Build > Build APK(s), or run `gradle :app:assembleDebug` from the project directory. The output is `app/build/outputs/apk/debug/app-debug.apk`. Alternatively put all files (including hidden `.github`) in the root of a private GitHub repo, open Actions > Build Android QA APK > Run workflow and download the resulting artifact after a successful build. No Gradle wrapper is bundled. 

## Test
1. Install your own game debug build and the QA APK. Use a local test environment without real rewards.
2. Enable RingBot QA test taps in Accessibility, then return to the app. Enter your debug game's exact applicationId. On Android 13+ sideloaded apps may need the OS's allow restricted settings option; only enable it for an app you trust.
3. Set center/radius and tap coordinates as fractions of the full portrait screen. Defaults approximate the supplied 1080x2436 footage. Allow full-screen sharing, not single-app sharing, then open your game. Stop using the foreground notification or QA activity. The program refuses taps unless the active package is debuggable and matches your entered package.
4. Start with 45 ms latency compensation, tune based on your debug game's logged tap timing. The initial thresholds are video-derived and may need adjustment. This is a prototype, not a verified high-accuracy solution. Landscape and dynamic layouts are not supported. 

The detector finds the dark shaft and pale target using polar samples, estimates angular velocity, predicts future angle, and suppresses repeated taps until the target changes. Confetti, overlays, low frame rate or small targets can make detection fail; no accuracy guarantee. Prefer a deterministic in-engine test hook for reliable QA.
