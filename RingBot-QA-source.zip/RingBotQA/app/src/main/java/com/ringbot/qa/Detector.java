package com.ringbot.qa;
import java.nio.ByteBuffer;
final class Detector {
 static final int N=720; static final double[] COS=new double[N],SIN=new double[N];static{for(int i=0;i<N;i++){COS[i]=Math.cos(i*Math.PI*2/N);SIN[i]=Math.sin(i*Math.PI*2/N);}}
 static double wrap(double a){return ((a+180)%360+360)%360-180;}
 static class Result{double angle,target,width;boolean valid,targetValid;}
 static Result scan(ByteBuffer b,int w,int h,int row,int pixel,double cy,double radius){Result out=new Result();int[] shaft=new int[N],zone=new int[N];double cx=w*.5, yy=h*cy, rr=w*radius;double[] inner={.634,.706,.778,.85,.908},outer={.994,1.037,1.08};
 for(int i=0;i<N;i++){for(double r:inner){int c=color(b,w,h,row,pixel,cx,yy,rr*r,i);if(Math.max((c>>16)&255,Math.max((c>>8)&255,c&255))<85)shaft[i]++;}for(double r:outer){int c=color(b,w,h,row,pixel,cx,yy,rr*r,i);int red=(c>>16)&255,g=(c>>8)&255,bl=c&255;if(red>170&&g>165&&bl>135&&red-bl>1&&g-bl>0&&Math.abs(red-g)<35)zone[i]++;}}
 int best=-1,peak=0;for(int i=0;i<N;i++){int v=0;for(int d=-5;d<=5;d++)v+=shaft[(i+d+N)%N];if(v>peak){peak=v;best=i;}}if(peak<22)return out;out.valid=true;out.angle=best*.5;
 double sx=0,sy=0;int count=0;for(int i=0;i<N;i++){if(zone[i]>=2&&Math.abs(wrap(i*.5-out.angle))>=11){sx+=COS[i];sy+=SIN[i];count++;}}if(count>=5&&count<=65&&Math.hypot(sx,sy)/count>.97){out.target=(Math.toDegrees(Math.atan2(sy,sx))+360)%360;out.width=count*.5;out.targetValid=true;}return out;}
 static int color(ByteBuffer b,int w,int h,int row,int pix,double cx,double cy,double r,int i){int x=(int)Math.round(cx+r*COS[i]),y=(int)Math.round(cy+r*SIN[i]);if(x<0||x>=w||y<0||y>=h)return 0xffffff;int p=y*row+x*pix;if(p+2>=b.limit())return 0xffffff;return ((b.get(p)&255)<<16)|((b.get(p+1)&255)<<8)|(b.get(p+2)&255);}
}
